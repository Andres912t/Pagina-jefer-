
<?php
$conexion = new mysqli("HOST", "USUARIO", "CONTRASENA", "NOMBRE_BASE_DATOS");
if ($conexion->connect_error) { die("Error: " . $conexion->connect_error); }
$resultado = $conexion->query("SELECT * FROM mensajes ORDER BY id DESC");
while($fila = $resultado->fetch_assoc()) {
    echo "<p>" . htmlspecialchars($fila['contenido']) . "</p>";
}
?>
