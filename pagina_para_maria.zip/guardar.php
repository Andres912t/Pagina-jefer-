
<?php
$conexion = new mysqli("HOST", "USUARIO", "CONTRASENA", "NOMBRE_BASE_DATOS");
if ($conexion->connect_error) { die("Error: " . $conexion->connect_error); }
$mensaje = $_POST['mensaje'];
$conexion->query("INSERT INTO mensajes (contenido) VALUES ('$mensaje')");
?>
